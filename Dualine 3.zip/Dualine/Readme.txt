=== Dualine ===
Contributors: ejslondon
Donate link: http://www.ejslondon.com
Tags: homepage, wordpress, security
Requires at least: 4.7
Tested up to: 5.7.1
Stable tag: 1.0.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Dualine allows you to have 2 homepages on your website!

== Description ==
Dualine allows you to have 2 homepages on your website, one for users (logged in) and another for guests (logged out). The plugin is super simple, yet, feature rich.

== Changelog ==
= 1.0.0 =
* Initial Release
= 0.0.1 =
* Initial Beta Releas

== Upgrade Notice ==